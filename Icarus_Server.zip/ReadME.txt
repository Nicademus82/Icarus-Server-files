#1 Run Steamcmd.exe file located in SteamCMD folder

#2 Run the Icarus_Update.bat file located in SteamCMD folder to create\update your icarus server

#3 Right-click Server_Start.bat file and edit the ("NAME OF YOUR SERVER") to whatever you like

#4 Run Server_Start.bat file 

* After starting your server for the first time it will create a ServerSettings.ini file located
 C:\icarus\Icarus\Saved\Config\WindowsServer\ServerSettings.ini
* If not just use the provided ServerSettings.ini file here and edit to fit your needs
* Shutdown server before attempting to update
* Server_Start.bat file is ready for auto server restart setup using Windows Task Scheduler