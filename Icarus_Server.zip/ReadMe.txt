#1 Download and install Steamcmd (you will have to create a folder to unzip Steamcmd into)

* https://steamcdn-a.akamaihd.net/client/installer/steamcmd.zip

#2 Place the Icarus_Update.bat file and Icarus.txt file into the Steamcmd folder you created

#3 Run the Icarus_Update.bat file to create\update your icarus folder C:\Icarus (Shutdown server before atempting to update)

#4 Place the Server_Start.bat file into C:\Icarus folder that you just created

#5 Right-click and edit the ("NAME OF YOUR SERVER") to whatever you like

#6 Run Server_Start.bat file

* After starting your server for the first time it will create a ServerSettings.ini file located
* C:\icarus\Icarus\Saved\Config\WindowsServer\ServerSettings.ini
* If not just download the provided ServerSettings.ini file here and edit to fit your needs
* Server_Start.bat file is ready for auto server restart setup using Windows Task Scheduler




